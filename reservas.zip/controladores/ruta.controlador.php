<?php

class ControladorRuta{

	static public function ctrRuta(){

		return "https://reservas.lingos.cl/";

	}

	static public function ctrServidor(){


		return "https://reservas.lingos.cl/backend/";
	}

}