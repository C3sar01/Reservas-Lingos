<footer class="main-footer">

	<strong>Copyright © <?php echo date("Y"); ?> <a href="<?php echo $ruta; ?>" 
	target="_blank">Lingos Talca</a>.</strong> Todos los derechos reservados.

</footer>