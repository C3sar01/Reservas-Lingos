<?php

$cafe = ControladorCafe::ctrMostrarCafe();



?>

<!--=====================================
CAFÉ
======================================-->

<div class="fondoRestaurante container-fluid">


</div>

<div class="restaurante container-fluid pt-5" id="restaurante">
	
	<div class="container">

		<div class="grid-container">
		
			<div class="grid-item carta">
				
				

			</div>

			<div class="grid-item bloqueRestaurante">
				
			   <h9>
			   <a href="<?php echo $ruta;  ?>">

               <img src="img/logokaffe.png" class="img-fluid kaffe" >

                </a>
				</h9>

				<p class="p-4 my-lg-5 descripcionKaffe">DISFRUTA DE UN COFFE BREAK EN EL PRIMER PISO DEL LOCAL EN CAFÉ KAFFE, DONDE TE OFRECEMOS CAFÉ DE GRANO FRESCO Y LOS MEJORES PRODUCTOS PARA ACOMPAÑAR TU EXQUISITO CAFÉ Y TU TARDE DE TRABAJO</p>

				

			</div>
			
		</div>		

	</div>

</div>