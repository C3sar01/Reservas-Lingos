<?php

include "modulos/banner-interior.php";
include "modulos/info-reservas.php";
include "modulos/habitaciones.php";
include "modulos/restaurante.php";
echo '<div class="mb-5"></div>';