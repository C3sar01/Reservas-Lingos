<?php

include "modulos/banner-interior.php";
include "modulos/info-habitaciones.php";
include "modulos/restaurante.php";